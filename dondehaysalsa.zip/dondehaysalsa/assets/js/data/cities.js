/* ==========================================================================
   Catálogo de ciudades.
   Agregar una ciudad aquí (con activa:true) la enciende automáticamente en
   los filtros, en la sección "Explora por ciudad", en el footer y le da su
   propia página. No hay que tocar ningún otro archivo.
   ========================================================================== */
window.DHS = window.DHS || {};

DHS.ciudades = [
  { id:1, nombre:'Puerto Vallarta', slug:'puerto-vallarta', estado:'Jalisco', pais:'México', latitud:20.6534, longitud:-105.2253, activa:true },
  { id:2, nombre:'Guadalajara',     slug:'guadalajara',     estado:'Jalisco', pais:'México', latitud:20.6597, longitud:-103.3496, activa:true },
  { id:3, nombre:'Ciudad de México',slug:'cdmx',            estado:'CDMX',    pais:'México', latitud:19.4326, longitud:-99.1332,  activa:true },
  { id:4, nombre:'Monterrey',       slug:'monterrey',       estado:'Nuevo León', pais:'México', latitud:25.6866, longitud:-100.3161, activa:false },
  { id:5, nombre:'Querétaro',       slug:'queretaro',       estado:'Querétaro',  pais:'México', latitud:20.5888, longitud:-100.3899, activa:false },
  { id:6, nombre:'León',            slug:'leon',            estado:'Guanajuato', pais:'México', latitud:21.1219, longitud:-101.6833, activa:false },
  { id:7, nombre:'Puebla',          slug:'puebla',          estado:'Puebla',     pais:'México', latitud:19.0414, longitud:-98.2063,  activa:false },
  { id:8, nombre:'Cancún',          slug:'cancun',          estado:'Quintana Roo', pais:'México', latitud:21.1619, longitud:-86.8515, activa:false },
  { id:9, nombre:'Mérida',          slug:'merida',          estado:'Yucatán',    pais:'México', latitud:20.9674, longitud:-89.5926,  activa:false }
];
