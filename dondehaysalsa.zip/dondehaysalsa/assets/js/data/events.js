/* ==========================================================================
   EVENTOS — aquí vive toda la cartelera.
   Para agregar un evento real: copia un bloque, cámbiale los datos y listo.

   `dias`  = dentro de cuántos días ocurre, contando desde hoy.
             Sirve para el contenido de ejemplo: la cartelera nunca se ve vacía.
   `fecha` = si prefieres una fecha fija, usa fecha:'2026-09-21' y borra `dias`.

   ⚠️ Los eventos de abajo son FICTICIOS (contenido de ejemplo).
      Reemplázalos por eventos reales antes de publicar el sitio.
   ========================================================================== */
window.DHS = window.DHS || {};

DHS.organizadores = [
  { id:1, nombre:'Vallarta Salsa Club', descripcion:'Escuela y club social con más de 10 años promoviendo la salsa en la bahía.', telefono:'+52 322 111 2233', whatsapp:'523221112233', instagram:'vallartasalsaclub', facebook:'vallartasalsaclub', email:'hola@ejemplo.mx' },
  { id:2, nombre:'Bahía Latina Producciones', descripcion:'Productora de conciertos y festivales de música latina en Puerto Vallarta.', telefono:'+52 322 444 5566', whatsapp:'523224445566', instagram:'bahialatina', facebook:'bahialatina', email:'contacto@ejemplo.mx' },
  { id:3, nombre:'Academia Son y Sabor', descripcion:'Clases de salsa, bachata y son cubano para todos los niveles.', telefono:'+52 322 777 8899', whatsapp:'523227778899', instagram:'sonysabormx', facebook:'sonysabormx', email:'clases@ejemplo.mx' },
  { id:4, nombre:'Ritmo GDL', descripcion:'Colectivo salsero de Guadalajara.', telefono:'+52 33 1234 5678', whatsapp:'523312345678', instagram:'ritmogdl', facebook:'ritmogdl', email:'info@ejemplo.mx' }
];

DHS.eventos = [
  {
    id:'social-viernes-vallarta', nombre:'Social Salsero del Viernes',
    descripcion:'El social clásico de Puerto Vallarta. Una hora de clase abierta para calentar y después pista libre hasta la madrugada con DJ en vivo. Salsa en línea, cubana y bachata. Ambiente familiar, bailadores de todos los niveles bienvenidos.',
    dias:0, hora:'21:00', lugar:'Salón Caribe', direccion:'Av. México 1234, Col. 5 de Diciembre',
    ciudad:'puerto-vallarta', precio:150, tipo_evento:'social', ritmos:['salsa','bachata'],
    flyer:'assets/img/flyers/social-viernes.svg', link_boletos:'', latitud:20.6280, longitud:-105.2350,
    organizador_id:1, destacado:true
  },
  {
    id:'salsa-en-vivo-malecon', nombre:'Salsa en Vivo: Orquesta Bahía',
    descripcion:'Concierto de la Orquesta Bahía con repertorio de salsa dura y clásicos de la Fania. Pista de baile amplia frente al mar. Llega temprano, el cupo es limitado.',
    dias:1, hora:'20:30', lugar:'Terraza Malecón', direccion:'Paseo Díaz Ordaz 660, Centro',
    ciudad:'puerto-vallarta', precio:350, tipo_evento:'salsa-en-vivo', ritmos:['salsa','son'],
    flyer:'assets/img/flyers/salsa-en-vivo.svg', link_boletos:'https://ejemplo.mx/boletos', latitud:20.6096, longitud:-105.2350,
    organizador_id:2, destacado:true
  },
  {
    id:'clase-principiantes-lunes', nombre:'Clase de Salsa desde Cero',
    descripcion:'Clase para quienes nunca han bailado. Aprendes el paso básico, la vuelta y a bailar en pareja en una sola sesión. No necesitas pareja ni experiencia.',
    dias:3, hora:'19:00', lugar:'Academia Son y Sabor', direccion:'Calle Lázaro Cárdenas 220, Emiliano Zapata',
    ciudad:'puerto-vallarta', precio:120, tipo_evento:'clase', ritmos:['salsa'],
    flyer:'assets/img/flyers/clase-principiantes.svg', link_boletos:'', latitud:20.6010, longitud:-105.2340,
    organizador_id:3, destacado:false
  },
  {
    id:'taller-styling-damas', nombre:'Taller de Styling',
    descripcion:'Taller intensivo de dos horas enfocado en postura, brazos, giros y expresión corporal. Nivel intermedio. Cupo limitado a 20 personas.',
    dias:5, hora:'17:00', lugar:'Estudio Bahía Dance', direccion:'Basilio Badillo 315, Zona Romántica',
    ciudad:'puerto-vallarta', precio:400, tipo_evento:'taller', ritmos:['salsa','mambo'],
    flyer:'assets/img/flyers/taller-styling.svg', link_boletos:'', latitud:20.6035, longitud:-105.2360,
    organizador_id:3, destacado:false
  },
  {
    id:'bachata-night-vallarta', nombre:'Bachata Night',
    descripcion:'Noche dedicada a la bachata: dominicana, sensual y moderna. Clase de entrada a las 21:00 y social hasta el cierre.',
    dias:2, hora:'21:30', lugar:'Club Mango', direccion:'Av. Francisco Medina Ascencio 2500, Zona Hotelera',
    ciudad:'puerto-vallarta', precio:180, tipo_evento:'social', ritmos:['bachata','kizomba'],
    flyer:'assets/img/flyers/bachata-night.svg', link_boletos:'', latitud:20.6520, longitud:-105.2280,
    organizador_id:1, destacado:false
  },
  {
    id:'fiesta-malecon-aire-libre', nombre:'Fiesta Salsera en el Malecón',
    descripcion:'Fiesta al aire libre con DJs invitados, food trucks y pista bajo las estrellas. Entrada libre para toda la familia.',
    dias:2, hora:'19:00', lugar:'Explanada del Malecón', direccion:'Malecón de Puerto Vallarta, Centro',
    ciudad:'puerto-vallarta', precio:0, tipo_evento:'fiesta', ritmos:['salsa','cumbia','bachata'],
    flyer:'assets/img/flyers/fiesta-malecon.svg', link_boletos:'', latitud:20.6120, longitud:-105.2355,
    organizador_id:2, destacado:true
  },
  {
    id:'noche-son-cubano', nombre:'Noche de Son Cubano y Rueda',
    descripcion:'Rueda de casino dirigida y social de son cubano. Se enseñan las figuras al inicio, así que puedes llegar sin saber la rueda.',
    dias:7, hora:'20:00', lugar:'Casa Cuba PV', direccion:'Calle Constitución 180, Centro',
    ciudad:'puerto-vallarta', precio:200, tipo_evento:'social', ritmos:['son','salsa-cubana'],
    flyer:'assets/img/flyers/son-cubano.svg', link_boletos:'', latitud:20.6060, longitud:-105.2320,
    organizador_id:1, destacado:false
  },
  {
    id:'festival-vallarta-salsa', nombre:'Festival Vallarta Salsa',
    descripcion:'Tres días de talleres con instructores internacionales, shows, competencias y fiestas hasta el amanecer. Pase completo o entrada por noche.',
    dias:12, hora:'16:00', lugar:'Hotel Bahía Resort', direccion:'Blvd. Francisco Medina Ascencio Km 2.5',
    ciudad:'puerto-vallarta', precio:1800, tipo_evento:'festival', ritmos:['salsa','bachata','kizomba','mambo'],
    flyer:'assets/img/flyers/festival-vallarta.svg', link_boletos:'https://ejemplo.mx/festival', latitud:20.6420, longitud:-105.2300,
    organizador_id:2, destacado:true
  },
  {
    id:'competencia-parejas-pv', nombre:'Competencia de Parejas y Solistas',
    descripcion:'Competencia abierta con categorías amateur y profesional. Jurado invitado y premiación en efectivo. Público bienvenido.',
    dias:19, hora:'18:00', lugar:'Teatro Vallarta', direccion:'Uruguay 184, 5 de Diciembre',
    ciudad:'puerto-vallarta', precio:250, tipo_evento:'competencia', ritmos:['salsa','mambo'],
    flyer:'assets/img/flyers/competencia.svg', link_boletos:'', latitud:20.6250, longitud:-105.2330,
    organizador_id:2, destacado:false
  },
  {
    id:'mambo-club-gdl', nombre:'Mambo Club On2',
    descripcion:'Social dedicado al estilo On2 neoyorquino, con DJ especializado y pista de madera.',
    dias:4, hora:'22:00', lugar:'Salón Providencia', direccion:'Av. Pablo Neruda 2720, Providencia',
    ciudad:'guadalajara', precio:200, tipo_evento:'social', ritmos:['mambo','salsa'],
    flyer:'assets/img/flyers/mambo-club.svg', link_boletos:'', latitud:20.7000, longitud:-103.3900,
    organizador_id:4, destacado:false
  },
  {
    id:'kizomba-sunset-pv', nombre:'Kizomba Sunset',
    descripcion:'Social de kizomba y semba al atardecer, en la playa. Trae ropa cómoda, se baila descalzo sobre duela.',
    dias:9, hora:'18:30', lugar:'Beach Club Palmar', direccion:'Playa Los Muertos, Zona Romántica',
    ciudad:'puerto-vallarta', precio:150, tipo_evento:'fiesta', ritmos:['kizomba','bachata'],
    flyer:'assets/img/flyers/kizomba-sunset.svg', link_boletos:'', latitud:20.5990, longitud:-105.2380,
    organizador_id:1, destacado:false
  },
  {
    id:'domingo-salsero-cdmx', nombre:'Domingo Salsero de Tarde',
    descripcion:'Social dominical de 5 a 10 de la noche. Ideal para quienes no quieren desvelarse pero sí quieren bailar.',
    dias:6, hora:'17:00', lugar:'Salón Los Ángeles', direccion:'Lerdo 206, Guerrero',
    ciudad:'cdmx', precio:180, tipo_evento:'social', ritmos:['salsa','son','cumbia'],
    flyer:'assets/img/flyers/domingo-salsero.svg', link_boletos:'', latitud:19.4520, longitud:-99.1450,
    organizador_id:4, destacado:false
  }
];
