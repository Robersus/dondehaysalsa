/* ==========================================================================
   Categorías: tipos de evento, ritmos y rangos de fecha de los filtros.
   ========================================================================== */
window.DHS = window.DHS || {};

DHS.tiposEvento = [
  { slug:'social',       nombre:'Social',        icono:'🔥' },
  { slug:'salsa-en-vivo',nombre:'Salsa en vivo', icono:'🎺' },
  { slug:'clase',        nombre:'Clase',         icono:'🕺' },
  { slug:'taller',       nombre:'Taller',        icono:'✨' },
  { slug:'festival',     nombre:'Festival',      icono:'🎪' },
  { slug:'congreso',     nombre:'Congreso',      icono:'🌎' },
  { slug:'competencia',  nombre:'Competencia',   icono:'🏆' },
  { slug:'fiesta',       nombre:'Fiesta',        icono:'🎉' }
];

DHS.ritmos = [
  { slug:'salsa',        nombre:'Salsa' },
  { slug:'bachata',      nombre:'Bachata' },
  { slug:'son',          nombre:'Son' },
  { slug:'mambo',        nombre:'Mambo' },
  { slug:'salsa-cubana', nombre:'Salsa Cubana' },
  { slug:'kizomba',      nombre:'Kizomba' },
  { slug:'cumbia',       nombre:'Cumbia' },
  { slug:'otros',        nombre:'Otros' }
];

DHS.rangosFecha = [
  { slug:'todos',       nombre:'Cualquier fecha' },
  { slug:'hoy',         nombre:'Hoy' },
  { slug:'manana',      nombre:'Mañana' },
  { slug:'fin-semana',  nombre:'Este fin de semana' },
  { slug:'semana',      nombre:'Esta semana' },
  { slug:'mes',         nombre:'Este mes' }
];
