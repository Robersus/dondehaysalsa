/* ==========================================================================
   Publicar evento (solo frontend).
   Valida los campos, muestra la vista previa del flyer, agrega el evento a la
   cartelera de este navegador y arma un mensaje de WhatsApp con todos los
   datos para que el organizador te lo mande. Sin servidor de por medio.
   ========================================================================== */
(function(){
  const U = DHS.util, D = DHS.data;
  let flyerDataUrl = '';

  document.addEventListener('DOMContentLoaded', init);

  function init(){
    DHS.layout.montar('publicar');
    llenarSelects();
    conectarFlyer();
    document.getElementById('form-publicar').addEventListener('submit', enviar);
    // Fecha mínima: hoy
    document.getElementById('p-fecha').min = U.aISO(U.hoy());
    U.observarReveal();
  }

  function llenarSelects(){
    const opt = (l) => l.map(x => `<option value="${x.slug}">${U.esc(x.nombre)}</option>`).join('');
    document.getElementById('p-ciudad').innerHTML =
      '<option value="">Selecciona…</option>' + opt(DHS.ciudades.filter(c => c.activa)) +
      '<optgroup label="Próximamente">' + opt(DHS.ciudades.filter(c => !c.activa)) + '</optgroup>';
    document.getElementById('p-tipo').innerHTML = '<option value="">Selecciona…</option>' + opt(DHS.tiposEvento);
    document.getElementById('p-ritmos').innerHTML = DHS.ritmos.map(r =>
      `<label class="chip" style="cursor:pointer"><input type="checkbox" value="${r.slug}" style="accent-color:var(--c-accent);margin-right:.35rem">${U.esc(r.nombre)}</label>`).join('');
  }

  function conectarFlyer(){
    const zona  = document.getElementById('dropzone');
    const input = document.getElementById('p-flyer');
    const prev  = document.getElementById('flyer-preview');

    zona.addEventListener('click', () => input.click());
    zona.addEventListener('dragover', e => { e.preventDefault(); zona.classList.add('is-drag'); });
    zona.addEventListener('dragleave', () => zona.classList.remove('is-drag'));
    zona.addEventListener('drop', e => {
      e.preventDefault(); zona.classList.remove('is-drag');
      if (e.dataTransfer.files[0]) { input.files = e.dataTransfer.files; leer(e.dataTransfer.files[0]); }
    });
    input.addEventListener('change', () => input.files[0] && leer(input.files[0]));

    function leer(file){
      if (!file.type.startsWith('image/')) return U.toast('El flyer debe ser una imagen');
      if (file.size > 3 * 1024 * 1024)    return U.toast('La imagen no debe pasar de 3 MB');
      const fr = new FileReader();
      fr.onload = () => { flyerDataUrl = fr.result; prev.src = fr.result; prev.hidden = false;
        document.getElementById('dropzone-texto').textContent = file.name; };
      fr.readAsDataURL(file);
    }
  }

  function invalidar(id, mensaje){
    const campo = document.getElementById(id).closest('.field');
    campo.classList.add('is-invalid');
    const err = campo.querySelector('.error');
    if (err && mensaje) err.textContent = mensaje;
    return false;
  }

  function validar(){
    document.querySelectorAll('.field.is-invalid').forEach(f => f.classList.remove('is-invalid'));
    let ok = true;
    const req = ['p-nombre','p-fecha','p-hora','p-lugar','p-ciudad','p-tipo','p-organizador'];
    req.forEach(id => { if (!document.getElementById(id).value.trim()) ok = invalidar(id, 'Este campo es obligatorio'); });

    const ritmos = [...document.querySelectorAll('#p-ritmos input:checked')];
    if (!ritmos.length){ document.getElementById('error-ritmos').style.display = 'block'; ok = false; }
    else document.getElementById('error-ritmos').style.display = 'none';

    const wa = document.getElementById('p-whatsapp').value.replace(/\D/g,'');
    if (wa && wa.length < 10) ok = invalidar('p-whatsapp', 'Escribe el número a 10 dígitos con LADA');

    if (!ok){
      const primero = document.querySelector('.field.is-invalid');
      if (primero) primero.scrollIntoView({ behavior:'smooth', block:'center' });
      U.toast('Revisa los campos marcados');
    }
    return ok;
  }

  /** Arma el mensaje que el organizador te envía por WhatsApp con todos los datos.
      Es la forma de recibir eventos reales sin necesidad de servidor. */
  function mensajeWhatsApp(ev){
    const BR = '\u200b';                       // marca de línea en blanco que sí sobrevive al filtro
    const ciudad = (DHS.ciudades.find(c => c.slug === ev.ciudad) || {}).nombre || ev.ciudad;
    const tipo   = (DHS.tiposEvento.find(t => t.slug === ev.tipo_evento) || {}).nombre || ev.tipo_evento;
    const ritmos = ev.ritmosNombres ? ev.ritmosNombres.join(', ') : (ev.ritmos || []).join(', ');

    const texto = [
      '*NUEVO EVENTO PARA LA CARTELERA*', BR,
      `*${ev.nombre}*`,
      `📅 ${U.fechaLarga(ev.fecha)} · ${U.hora12(ev.hora)}`,
      `📍 ${ev.lugar}${ev.direccion ? ' — ' + ev.direccion : ''}`,
      `🏙️ ${ciudad}`,
      `💵 ${U.precio(ev.precio)}`,
      `💃 ${tipo}`,
      `🎵 ${ritmos}`, BR,
      `Organiza: ${ev.organizador_nombre}`,
      ev.whatsapp     ? `WhatsApp: ${ev.whatsapp}` : '',
      ev.instagram    ? `Instagram: @${ev.instagram}` : '',
      ev.facebook     ? `Facebook: ${ev.facebook}` : '',
      ev.link_boletos ? `Boletos: ${ev.link_boletos}` : '',
      ev.descripcion  ? BR + '\n' + ev.descripcion : '', BR,
      'Enseguida les mando el flyer.'
    ].filter(Boolean).join('\n').split(BR).join('');

    return `https://wa.me/${DHS.config.contacto.whatsapp}?text=${encodeURIComponent(texto)}`;
  }

  async function enviar(e){
    e.preventDefault();
    if (!validar()) return;
    const v = id => document.getElementById(id).value.trim();
    const btn = document.getElementById('btn-enviar');
    btn.disabled = true; btn.textContent = 'Publicando…';

    const datos = {
      nombre: v('p-nombre'), descripcion: v('p-descripcion'),
      fecha: v('p-fecha'), hora: v('p-hora'),
      lugar: v('p-lugar'), direccion: v('p-direccion'), ciudad: v('p-ciudad'),
      precio: Number(v('p-precio') || 0),
      tipo_evento: v('p-tipo'),
      ritmos: [...document.querySelectorAll('#p-ritmos input:checked')].map(i => i.value),
      flyer: flyerDataUrl || 'assets/img/flyers/social-viernes.svg',
      organizador_nombre: v('p-organizador'),
      whatsapp: v('p-whatsapp').replace(/\D/g,''),
      instagram: v('p-instagram').replace('@',''),
      facebook: v('p-facebook'),
      link_boletos: v('p-boletos')
    };

    try{
      const creado = await D.crearEvento(datos);
      document.getElementById('form-publicar').hidden = true;
      document.getElementById('intro-publicar').hidden = true;
      const ok = document.getElementById('exito');
      ok.classList.add('is-visible');
      document.getElementById('exito-detalle').textContent =
        `${creado.nombre} · ${U.fechaLarga(creado.fecha)} · ${U.hora12(creado.hora)}`;
      document.getElementById('exito-ver').href = U.url('evento.html', { id: creado.id });
      document.getElementById('exito-whatsapp').href = mensajeWhatsApp(creado);
      ok.scrollIntoView({ behavior:'smooth', block:'center' });
    }catch(err){
      U.toast('No pudimos guardar el evento. Intenta de nuevo.');
      btn.disabled = false; btn.textContent = 'PUBLICAR EVENTO';
    }
  }
})();
