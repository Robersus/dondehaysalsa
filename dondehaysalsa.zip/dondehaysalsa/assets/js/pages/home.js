/* ==========================================================================
   Página principal: hero + buscador + cartelera + ciudades + mapa + CTA.
   ========================================================================== */
(function(){
  const U = DHS.util, D = DHS.data, F = DHS.filters;
  let estado = { q:'', ciudad:'todas', fecha:'todos', tipo:'todos', ritmo:'todos' };

  document.addEventListener('DOMContentLoaded', init);

  async function init(){
    DHS.layout.montar('eventos');

    // Estado inicial desde la URL (permite compartir búsquedas: index.html?ciudad=cdmx&fecha=hoy)
    const p = U.params();
    estado = { ...estado, ...p, ciudad: p.ciudad || DHS.config.ciudadDefault };

    F.render(document.getElementById('hero-search'));
    F.escribir(estado);
    F.quickchips(document.getElementById('quickfilters'), buscar);
    F.sincronizarChips(estado.fecha);

    document.getElementById('form-filtros').addEventListener('submit', e => { e.preventDefault(); buscar(true); });
    document.getElementById('btn-limpiar').addEventListener('click', limpiar);
    ['f-ciudad','f-fecha','f-tipo','f-ritmo'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.addEventListener('change', () => buscar());
    });

    await Promise.all([ buscar(), pintarCiudades(), pintarStats() ]);
    U.observarReveal();
  }

  async function buscar(irACartelera){
    estado = F.leer();
    F.sincronizarChips(estado.fecha);
    const cont = document.getElementById('lista-eventos');
    cont.setAttribute('aria-busy','true');

    const eventos = await D.listarEventos(estado);
    DHS.eventCard.pintar(cont, eventos);
    cont.setAttribute('aria-busy','false');

    const c = document.getElementById('contador');
    if (c) c.textContent = eventos.length === 1 ? '1 evento' : `${eventos.length} eventos`;

    // La URL refleja la búsqueda: se puede compartir y es amigable para SEO futuro.
    const qs = new URLSearchParams(Object.entries(estado)
      .filter(([,v]) => v && v !== 'todas' && v !== 'todos')).toString();
    history.replaceState(null, '', qs ? `?${qs}` : location.pathname);

    if (irACartelera) document.getElementById('cartelera').scrollIntoView({ behavior:'smooth', block:'start' });
  }

  function limpiar(){
    ['f-q','f-ciudad','f-fecha','f-tipo','f-ritmo'].forEach(id => {
      const el = document.getElementById(id); if (!el) return;
      el.value = el.tagName === 'SELECT' ? el.options[0].value : '';
    });
    buscar();
  }

  async function pintarCiudades(){
    const [ciudades, conteo] = await Promise.all([ D.listarCiudades(), D.contarPorCiudad() ]);
    document.getElementById('lista-ciudades').innerHTML = ciudades.map(c => {
      const n = conteo[c.slug] || 0;
      if (!c.activa) return `<div class="city city--soon"><b>${U.esc(c.nombre)}</b><span>Próximamente</span></div>`;
      return `<a class="city reveal" href="${U.url('ciudad.html',{ c:c.slug })}">
        <b>${U.esc(c.nombre)}</b><span>${n} ${n === 1 ? 'evento' : 'eventos'} · ${U.esc(c.estado)}</span></a>`;
    }).join('');
  }

  async function pintarStats(){
    const eventos = await D.listarEventos({});
    const ciudades = new Set(eventos.map(e => e.ciudad));
    const estaSemana = eventos.filter(e => U.diasEntre(U.hoy(), U.parseFecha(e.fecha)) <= 7).length;
    const set = (id,v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    set('stat-eventos', eventos.length);
    set('stat-ciudades', ciudades.size);
    set('stat-semana', estaSemana);

    // Marcadores del mapa (posición relativa dentro del recuadro, listo para sustituir por un mapa real)
    const mapa = document.getElementById('mapa-pins');
    if (mapa){
      mapa.innerHTML = eventos.slice(0,7).map((e,i) => {
        const x = 12 + (i * 13) % 76, y = 18 + ((i * 29) % 62);
        return `<span class="map__pin" style="left:${x}%;top:${y}%;animation-delay:${i * .28}s" title="${U.esc(e.nombre)}"></span>`;
      }).join('');
    }
  }
})();
