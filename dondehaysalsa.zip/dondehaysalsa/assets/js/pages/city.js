/* ==========================================================================
   Página de ciudad: /ciudad.html?c=puerto-vallarta
   Misma cartelera, filtrada y con la ciudad fija.
   ========================================================================== */
(function(){
  const U = DHS.util, D = DHS.data, F = DHS.filters;
  let slug = null;

  document.addEventListener('DOMContentLoaded', init);

  async function init(){
    DHS.layout.montar('ciudades');
    slug = U.params().c || DHS.config.ciudadLanzamiento;
    const ciudad = await D.obtenerCiudad(slug);

    if (!ciudad || !ciudad.activa){
      document.getElementById('ciudad-hero').innerHTML = `
        <div class="empty"><h3>Todavía no llegamos a esta ciudad</h3>
        <p>Estamos abriendo ciudad por ciudad. Si organizas eventos aquí, publícalo y la activamos.</p>
        <p style="margin-top:1rem"><a class="btn btn--primary" href="publicar.html">Publicar mi evento</a>
        <a class="btn btn--ghost" href="index.html" style="margin-left:.5rem">Ver otras ciudades</a></p></div>`;
      document.getElementById('bloque-cartelera').hidden = true;
      return;
    }

    document.title = `Eventos de salsa en ${ciudad.nombre} | ${DHS.config.nombre}`;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute('content',
      `Cartelera de salsa, bachata y ritmos latinos en ${ciudad.nombre}, ${ciudad.estado}. Sociales, clases, conciertos y festivales actualizados.`);

    document.getElementById('ciudad-hero').innerHTML = `
      <span class="eyebrow">${U.esc(ciudad.estado)}, ${U.esc(ciudad.pais)}</span>
      <h1>Salsa en <em>${U.esc(ciudad.nombre)}</em></h1>
      <p class="hero__sub">Todos los sociales, clases, conciertos y fiestas salseras de ${U.esc(ciudad.nombre)} en un solo lugar.</p>`;

    document.getElementById('breadcrumb').innerHTML =
      `<a href="index.html">Inicio</a> › <a href="index.html#ciudades">Ciudades</a> › <span>${U.esc(ciudad.nombre)}</span>`;

    F.render(document.getElementById('ciudad-filtros'), { ciudadFija:true });
    F.quickchips(document.getElementById('quickfilters'), buscar);
    document.getElementById('form-filtros').addEventListener('submit', e => { e.preventDefault(); buscar(); });
    document.getElementById('btn-limpiar').addEventListener('click', () => {
      ['f-q','f-fecha','f-tipo','f-ritmo'].forEach(id => {
        const el = document.getElementById(id); if (!el) return;
        el.value = el.tagName === 'SELECT' ? el.options[0].value : '';
      });
      buscar();
    });
    ['f-fecha','f-tipo','f-ritmo'].forEach(id => {
      const el = document.getElementById(id); if (el) el.addEventListener('change', buscar);
    });

    await buscar();
    U.observarReveal();
  }

  async function buscar(){
    const estado = F.leer({ ciudadFija: slug });
    F.sincronizarChips(estado.fecha);
    const eventos = await D.listarEventos(estado);
    DHS.eventCard.pintar(document.getElementById('lista-eventos'), eventos);
    const c = document.getElementById('contador');
    if (c) c.textContent = eventos.length === 1 ? '1 evento' : `${eventos.length} eventos`;
  }
})();
