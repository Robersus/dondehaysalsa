/* ==========================================================================
   Página individual del evento.
   ========================================================================== */
(function(){
  const U = DHS.util, D = DHS.data;
  document.addEventListener('DOMContentLoaded', init);

  async function init(){
    DHS.layout.montar('eventos');
    const id = U.params().id;
    const ev = id ? await D.obtenerEvento(id) : null;
    const cont = document.getElementById('evento');

    if (!ev){
      cont.innerHTML = `<div class="empty" style="grid-column:1/-1">
        <h3>No encontramos este evento</h3>
        <p>Puede que ya haya pasado o que el enlace esté incompleto.</p>
        <p style="margin-top:1rem"><a class="btn btn--primary" href="index.html">Ver la cartelera</a></p></div>`;
      return;
    }

    document.title = `${ev.nombre} · ${ev.ciudadNombre} | ${DHS.config.nombre}`;
    setMeta('description', `${ev.nombre} — ${U.fechaLarga(ev.fecha)} a las ${U.hora12(ev.hora)} en ${ev.lugar}, ${ev.ciudadNombre}. ${U.precio(ev.precio)}.`);
    setMeta('og:title', ev.nombre, true);
    setMeta('og:description', `${U.fechaLarga(ev.fecha)} · ${ev.lugar}, ${ev.ciudadNombre}`, true);
    setMeta('og:image', DHS.config.baseUrl + ev.flyer, true);

    pintar(cont, ev);
    pintarBreadcrumb(ev);
    stickybar(ev);
    datosEstructurados(ev);
    conectarCompartir(ev);
    await relacionados(ev);
    U.observarReveal();
  }

  function pintar(cont, ev){
    const maps = ev.latitud && ev.longitud
      ? `https://www.google.com/maps/search/?api=1&query=${ev.latitud},${ev.longitud}`
      : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(ev.lugar + ' ' + ev.direccion + ' ' + ev.ciudadNombre)}`;
    const org = ev.organizador;
    const destino = ev.link_boletos
      ? ev.link_boletos
      : (org && org.whatsapp
          ? `https://wa.me/${org.whatsapp}?text=${encodeURIComponent('Hola, vi "' + ev.nombre + '" en ¿Dónde Hay Salsa? y quiero ir. ¿Me das más información?')}`
          : maps);

    cont.innerHTML = `
<div class="event__flyer reveal">
  <img src="${U.esc(ev.flyer)}" alt="Flyer de ${U.esc(ev.nombre)}" width="800" height="1000">
</div>
<div class="reveal">
  <div class="event__tags">
    ${ev.destacado ? '<span class="chip chip--gold">⭐ Evento destacado</span>' : ''}
    <span class="chip chip--accent">${ev.tipoObj.icono} ${U.esc(ev.tipoObj.nombre)}</span>
    ${ev.ritmosNombres.map(r => `<span class="chip">${U.esc(r)}</span>`).join('')}
  </div>
  <h1 class="event__title">${U.esc(ev.nombre)}</h1>
  <p class="text-soft">${U.esc(U.fechaRelativa(ev.fecha))} · ${U.esc(U.fechaLarga(ev.fecha))} · ${U.hora12(ev.hora)}</p>

  <div class="event__actions">
    <a class="btn btn--primary btn--lg" href="${U.esc(destino)}" target="_blank" rel="noopener">QUIERO IR</a>
    <a class="btn btn--ghost btn--lg" href="${maps}" target="_blank" rel="noopener">📍 Cómo llegar</a>
  </div>

  <p class="event__desc">${U.esc(ev.descripcion)}</p>

  <dl class="datalist">
    <div><dt>Fecha</dt><dd>${U.esc(U.fechaLarga(ev.fecha))}</dd></div>
    <div><dt>Hora</dt><dd>${U.hora12(ev.hora)}</dd></div>
    <div><dt>Lugar</dt><dd>${U.esc(ev.lugar)}</dd></div>
    <div><dt>Dirección</dt><dd>${U.esc(ev.direccion)}</dd></div>
    <div><dt>Ciudad</dt><dd>${U.esc(ev.ciudadNombre)}${ev.ciudadObj ? ', ' + U.esc(ev.ciudadObj.estado) : ''}</dd></div>
    <div><dt>Precio</dt><dd>${U.esc(U.precio(ev.precio))}</dd></div>
  </dl>

  <h3 style="font-size:var(--fs-h3);margin-bottom:.6rem">Compartir</h3>
  <div class="share">
    <button type="button" data-share="whatsapp">💬 WhatsApp</button>
    <button type="button" data-share="facebook">📘 Facebook</button>
    <button type="button" data-share="copiar">🔗 Copiar enlace</button>
    <button type="button" data-share="nativo" hidden>📤 Compartir</button>
  </div>

  ${org ? `
  <div class="organizer">
    <span class="eyebrow">Organizador</span>
    <h3 style="margin-top:.4rem">${U.esc(org.nombre)}</h3>
    <p>${U.esc(org.descripcion)}</p>
    <div class="organizer__links">
      ${org.whatsapp  ? `<a class="btn btn--ghost" href="https://wa.me/${U.esc(org.whatsapp)}" target="_blank" rel="noopener">WhatsApp</a>` : ''}
      ${org.instagram ? `<a class="btn btn--ghost" href="https://instagram.com/${U.esc(org.instagram)}" target="_blank" rel="noopener">Instagram</a>` : ''}
      ${org.facebook  ? `<a class="btn btn--ghost" href="https://facebook.com/${U.esc(org.facebook)}" target="_blank" rel="noopener">Facebook</a>` : ''}
    </div>
  </div>` : ''}
</div>`;
  }

  function pintarBreadcrumb(ev){
    const bc = document.getElementById('breadcrumb');
    if (bc) bc.innerHTML = `<a href="index.html">Inicio</a> ›
      <a href="${U.url('ciudad.html',{ c:ev.ciudad })}">${U.esc(ev.ciudadNombre)}</a> ›
      <span>${U.esc(ev.nombre)}</span>`;
  }

  function stickybar(ev){
    document.body.classList.add('has-stickybar');
    const bar = document.getElementById('stickybar');
    const org = ev.organizador;
    const destino = ev.link_boletos || (org && org.whatsapp ? `https://wa.me/${org.whatsapp}` : '#');
    bar.innerHTML = `<div><b>${U.esc(U.precio(ev.precio))}</b><small>${U.esc(U.fechaRelativa(ev.fecha))} · ${U.hora12(ev.hora)}</small></div>
      <a class="btn btn--primary" href="${U.esc(destino)}" target="_blank" rel="noopener">QUIERO IR</a>`;
  }

  function conectarCompartir(ev){
    const url = location.href;
    const texto = `${ev.nombre} — ${U.fechaLarga(ev.fecha)} en ${ev.lugar}, ${ev.ciudadNombre}`;
    const nativo = document.querySelector('[data-share="nativo"]');
    if (navigator.share && nativo) nativo.hidden = false;

    document.querySelectorAll('[data-share]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const tipo = btn.dataset.share;
        if (tipo === 'whatsapp') window.open(`https://wa.me/?text=${encodeURIComponent(texto + ' → ' + url)}`, '_blank');
        if (tipo === 'facebook') window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
        if (tipo === 'nativo')   { try{ await navigator.share({ title:ev.nombre, text:texto, url }); }catch(e){} }
        if (tipo === 'copiar'){
          try{ await navigator.clipboard.writeText(url); U.toast('Enlace copiado ✅'); }
          catch(e){ U.toast('Copia el enlace desde la barra del navegador'); }
        }
      });
    });
  }

  async function relacionados(ev){
    const todos = await D.listarEventos({ ciudad: ev.ciudad });
    const otros = todos.filter(e => e.id !== ev.id).slice(0,4);
    const sec = document.getElementById('relacionados');
    if (!otros.length){ sec.hidden = true; return; }
    document.getElementById('relacionados-titulo').textContent = `Más salsa en ${ev.ciudadNombre}`;
    DHS.eventCard.pintar(document.getElementById('lista-relacionados'), otros);
  }

  function setMeta(nombre, contenido, esOg){
    const attr = esOg ? 'property' : 'name';
    let el = document.querySelector(`meta[${attr}="${nombre}"]`);
    if (!el){ el = document.createElement('meta'); el.setAttribute(attr, nombre); document.head.appendChild(el); }
    el.setAttribute('content', contenido);
  }

  /** Schema.org Event: mejora cómo se ve el evento en Google. */
  function datosEstructurados(ev){
    const json = {
      '@context':'https://schema.org', '@type':'Event',
      name: ev.nombre, description: ev.descripcion,
      startDate: `${ev.fecha}T${ev.hora}:00-06:00`,
      eventStatus:'https://schema.org/EventScheduled',
      eventAttendanceMode:'https://schema.org/OfflineEventAttendanceMode',
      image: [DHS.config.baseUrl + ev.flyer],
      location: { '@type':'Place', name: ev.lugar,
        address: { '@type':'PostalAddress', streetAddress: ev.direccion, addressLocality: ev.ciudadNombre, addressCountry:'MX' } },
      offers: { '@type':'Offer', price: ev.precio || 0, priceCurrency:'MXN', url: location.href },
      organizer: ev.organizador ? { '@type':'Organization', name: ev.organizador.nombre } : undefined
    };
    const s = document.createElement('script');
    s.type = 'application/ld+json';
    s.textContent = JSON.stringify(json);
    document.head.appendChild(s);
  }
})();
