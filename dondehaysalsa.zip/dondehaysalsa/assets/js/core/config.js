/* ==========================================================================
   Configuración global de la plataforma.
   Cambiar algo aquí NO requiere tocar el resto del código.
   ========================================================================== */
window.DHS = window.DHS || {};

DHS.config = {
  nombre: '¿Dónde Hay Salsa?',
  tagline: 'La cartelera salsera de México',

  // Ciudad seleccionada al abrir la página: 'todas' o el slug de una ciudad.
  ciudadDefault: 'todas',
  // Ciudad que se muestra si alguien entra a ciudad.html sin especificar cuál.
  ciudadLanzamiento: 'puerto-vallarta',

  // Poner en false cuando ya tengas eventos reales: oculta el aviso amarillo de arriba.
  mostrarAvisoEjemplo: true,

  contacto: {
    whatsapp: '523221234567',   // tu número, con lada de país y sin signos
    instagram: 'dondehaysalsa',
    email: 'hola@dondehaysalsa.mx'
  },

  // Base para construir enlaces absolutos al compartir. Se calcula sola.
  baseUrl: location.origin + location.pathname.replace(/[^/]*$/, '')
};
