/* ==========================================================================
   Utilidades: fechas, precios, slugs, URLs, DOM.
   ========================================================================== */
window.DHS = window.DHS || {};

DHS.util = (function(){
  const DIAS   = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
  const MESES  = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
  const MESES_C= ['ENE','FEB','MAR','ABR','MAY','JUN','JUL','AGO','SEP','OCT','NOV','DIC'];

  /** Fecha local a medianoche (evita el corrimiento de zona horaria de new Date('YYYY-MM-DD')) */
  function parseFecha(iso){
    const [y,m,d] = String(iso).split('-').map(Number);
    return new Date(y, m - 1, d);
  }
  function hoy(){ const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), n.getDate()); }
  function aISO(date){
    const p = n => String(n).padStart(2,'0');
    return `${date.getFullYear()}-${p(date.getMonth()+1)}-${p(date.getDate())}`;
  }
  function diasEntre(a,b){ return Math.round((b - a) / 86400000); }

  /** "Viernes 21 de agosto" */
  function fechaLarga(iso){
    const d = parseFecha(iso);
    return `${DIAS[d.getDay()]} ${d.getDate()} de ${MESES[d.getMonth()]}`;
  }
  /** { dia:'21', mes:'AGO' } para la esquina de la tarjeta */
  function fechaCorta(iso){
    const d = parseFecha(iso);
    return { dia:String(d.getDate()), mes:MESES_C[d.getMonth()] };
  }
  /** "Hoy", "Mañana" o la fecha larga */
  function fechaRelativa(iso){
    const diff = diasEntre(hoy(), parseFecha(iso));
    if (diff === 0) return 'Hoy';
    if (diff === 1) return 'Mañana';
    return fechaLarga(iso);
  }
  /** 21:00 -> 9:00 PM */
  function hora12(hhmm){
    const [h,m] = String(hhmm).split(':').map(Number);
    const suf = h >= 12 ? 'PM' : 'AM';
    const h12 = h % 12 === 0 ? 12 : h % 12;
    return `${h12}:${String(m).padStart(2,'0')} ${suf}`;
  }
  function precio(n){
    if (n === 0 || n === null || n === undefined || n === '') return 'Gratis';
    return '$' + Number(n).toLocaleString('es-MX');
  }
  function slugify(txt){
    return String(txt).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')
      .replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,60);
  }
  function esc(s){
    return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }
  /** Lee los parámetros de la URL (?ciudad=...&tipo=...) */
  function params(){ return Object.fromEntries(new URLSearchParams(location.search)); }

  /** URL de una página respetando la carpeta base (funciona en GitHub Pages en subcarpeta) */
  function url(pagina, query){
    const qs = query ? '?' + new URLSearchParams(
      Object.entries(query).filter(([,v]) => v !== '' && v !== null && v !== undefined && v !== 'todas' && v !== 'todos')
    ).toString() : '';
    return pagina + (qs === '?' ? '' : qs);
  }

  function toast(msg){
    let el = document.querySelector('.toast');
    if (!el){ el = document.createElement('div'); el.className = 'toast'; document.body.appendChild(el); }
    el.textContent = msg;
    requestAnimationFrame(() => el.classList.add('is-visible'));
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove('is-visible'), 2800);
  }

  /** Animación de entrada al hacer scroll */
  function observarReveal(scope){
    const items = (scope || document).querySelectorAll('.reveal:not(.is-visible)');
    if (!('IntersectionObserver' in window)){ items.forEach(i => i.classList.add('is-visible')); return; }
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting){ e.target.classList.add('is-visible'); io.unobserve(e.target); } });
    }, { rootMargin:'0px 0px -40px 0px' });
    items.forEach(i => io.observe(i));
  }

  return { parseFecha, hoy, aISO, diasEntre, fechaLarga, fechaCorta, fechaRelativa,
           hora12, precio, slugify, esc, params, url, toast, observarReveal, DIAS, MESES };
})();
