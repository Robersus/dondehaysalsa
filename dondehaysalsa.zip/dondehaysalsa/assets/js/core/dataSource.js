/* ==========================================================================
   CAPA DE DATOS — el único punto de contacto entre las páginas y los datos.
   Todo vive en el navegador: arreglos en JS. No hay servidor ni base de datos.

   Si algún día conectas un backend, se cambia SOLO este archivo:
   las páginas nunca leen los arreglos directamente, siempre llaman a DHS.data.
   Por eso los métodos son asíncronos (async) aunque hoy respondan al instante.
   ========================================================================== */
window.DHS = window.DHS || {};

DHS.data = (function(){
  const U = DHS.util;

  /* ---------- Normalización: un evento siempre tiene la misma forma ----------
     Convierte el objeto "crudo" del archivo de datos en uno listo para pintar:
     resuelve la ciudad, el tipo, los nombres de los ritmos y el organizador. */
  function normalizar(ev){
    const ciudad = DHS.ciudades.find(c => c.slug === ev.ciudad) || null;
    const tipo   = DHS.tiposEvento.find(t => t.slug === ev.tipo_evento) || { slug:ev.tipo_evento, nombre:ev.tipo_evento, icono:'🎵' };
    const org    = DHS.organizadores.find(o => o.id === ev.organizador_id) || null;
    // Si el evento trae `dias` en vez de `fecha`, se calcula desde hoy.
    // Así la cartelera de ejemplo nunca se ve vacía ni caduca.
    const fecha  = ev.fecha || U.aISO(new Date(U.hoy().getTime() + (ev.dias || 0) * 86400000));
    return {
      ...ev,
      fecha,
      ciudadObj: ciudad,
      ciudadNombre: ciudad ? ciudad.nombre : ev.ciudad,
      tipoObj: tipo,
      ritmosNombres: (ev.ritmos || []).map(r => (DHS.ritmos.find(x => x.slug === r) || { nombre:r }).nombre),
      organizador: org
    };
  }

  /* ---------- Filtro por rango de fecha ---------- */
  function dentroDeRango(fechaISO, rango){
    const hoy = U.hoy();
    const f = U.parseFecha(fechaISO);
    const diff = U.diasEntre(hoy, f);
    if (diff < 0) return false;                       // nunca mostramos eventos pasados
    switch (rango){
      case 'hoy':        return diff === 0;
      case 'manana':     return diff === 1;
      case 'fin-semana': {                            // viernes, sábado y domingo próximos
        const dow = hoy.getDay();                     // 0 domingo … 6 sábado
        const haciaViernes = (5 - dow + 7) % 7;
        const ini = dow === 0 ? 0 : haciaViernes;     // si hoy es domingo, ya estamos en el fin de semana
        const fin = dow === 0 ? 0 : ini + 2;
        return diff >= ini && diff <= fin;
      }
      case 'semana':     return diff <= 7;
      case 'mes':        return f.getMonth() === hoy.getMonth() && f.getFullYear() === hoy.getFullYear();
      default:           return true;                 // 'todos'
    }
  }

  /* ---------- Filtros de búsqueda ---------- */
  function aplicarFiltros(lista, f){
    f = f || {};
    const q = (f.q || '').trim().toLowerCase();
    return lista.filter(ev => {
      if (ev.publicado === false) return false;
      if (f.ciudad && f.ciudad !== 'todas' && ev.ciudad !== f.ciudad) return false;
      if (f.tipo   && f.tipo   !== 'todos'  && ev.tipo_evento !== f.tipo) return false;
      if (f.ritmo  && f.ritmo  !== 'todos'  && !(ev.ritmos || []).includes(f.ritmo)) return false;
      if (!dentroDeRango(ev.fecha, f.fecha || 'todos')) return false;
      if (q){
        const texto = [ev.nombre, ev.descripcion, ev.lugar, ev.ciudadNombre, ev.tipoObj.nombre,
                       ...(ev.ritmosNombres || []), ev.organizador && ev.organizador.nombre]
                      .join(' ').toLowerCase();
        if (!texto.includes(q)) return false;
      }
      return true;
    });
  }

  /** Destacados primero, después por fecha y hora. */
  function ordenar(lista){
    return lista.sort((a,b) => {
      if (a.destacado !== b.destacado) return a.destacado ? -1 : 1;
      return a.fecha === b.fecha ? a.hora.localeCompare(b.hora) : a.fecha.localeCompare(b.fecha);
    });
  }

  /** Eventos capturados desde el formulario. Se guardan en el navegador
      (localStorage) solo para que puedas ver cómo se vería tu evento publicado. */
  function eventosDelNavegador(){
    try{ return JSON.parse(localStorage.getItem('dhs_mis_eventos') || '[]').map(normalizar); }
    catch(e){ return []; }
  }

  function todos(){
    return DHS.eventos.map(normalizar).concat(eventosDelNavegador());
  }

  /* ---------- API pública: lo único que usan las páginas ---------- */
  return {
    async listarEventos(filtros){ return ordenar(aplicarFiltros(todos(), filtros)); },

    async obtenerEvento(id){ return todos().find(e => e.id === id) || null; },

    async listarCiudades(){ return DHS.ciudades.slice(); },

    async obtenerCiudad(slug){ return DHS.ciudades.find(c => c.slug === slug) || null; },

    async contarPorCiudad(){
      return ordenar(aplicarFiltros(todos(), {}))
        .reduce((acc,e) => (acc[e.ciudad] = (acc[e.ciudad] || 0) + 1, acc), {});
    },

    async crearEvento(datos){
      const id = U.slugify(datos.nombre) + '-' + Date.now().toString(36);
      const nuevo = { ...datos, id, destacado:false, publicado:true, creado_en:new Date().toISOString() };
      const mios = JSON.parse(localStorage.getItem('dhs_mis_eventos') || '[]');
      mios.push(nuevo);
      localStorage.setItem('dhs_mis_eventos', JSON.stringify(mios));
      return normalizar(nuevo);
    },

    /** Borra los eventos que capturaste desde el formulario. */
    async limpiarMisEventos(){ localStorage.removeItem('dhs_mis_eventos'); }
  };
})();
