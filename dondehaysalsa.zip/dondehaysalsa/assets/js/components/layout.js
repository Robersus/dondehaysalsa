/* ==========================================================================
   Navbar + footer + barra de aviso DEMO.
   Se inyectan por JS para que exista una sola fuente de verdad en todo el sitio.
   ========================================================================== */
window.DHS = window.DHS || {};

DHS.layout = (function(){
  const U = DHS.util;

  const LINKS = [
    { href:'index.html#cartelera', texto:'Eventos',  key:'eventos' },
    { href:'index.html#ciudades',  texto:'Ciudades', key:'ciudades' },
    { href:'index.html#mapa',      texto:'Mapa',     key:'mapa' },
    { href:'publicar.html',        texto:'Publicar evento', key:'publicar' }
  ];

  function navbar(activo){
    const links = LINKS.filter(l => l.key !== 'publicar').map(l =>
      `<a href="${l.href}"${l.key === activo ? ' aria-current="page"' : ''}>${l.texto}</a>`).join('');
    const aviso = DHS.config.mostrarAvisoEjemplo
      ? '<div class="demo-bar">Contenido de ejemplo · los eventos mostrados son ficticios</div>' : '';
    return `
${aviso}
<header class="nav">
  <div class="container nav__inner">
    <a class="logo" href="index.html" aria-label="${U.esc(DHS.config.nombre)} — inicio">
      <span class="logo__mark" aria-hidden="true">💃</span>
      <span class="logo__text">¿DÓNDE HAY <b>SALSA</b>?</span>
    </a>
    <nav class="nav__links" aria-label="Navegación principal">${links}</nav>
    <div class="nav__actions">
      <a class="btn btn--primary nav__cta" href="publicar.html">+ Publicar evento</a>
      <button class="nav__burger" type="button" aria-label="Abrir menú" aria-expanded="false" aria-controls="menu-movil">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>
</header>
<nav class="nav__mobile" id="menu-movil" aria-label="Navegación móvil">
  ${LINKS.map(l => `<a href="${l.href}">${l.texto}</a>`).join('')}
  <a class="btn btn--primary btn--block" href="publicar.html">+ Publicar evento</a>
</nav>`;
  }

  function footer(){
    const ciudadesActivas = DHS.ciudades.filter(c => c.activa)
      .map(c => `<a href="${U.url('ciudad.html',{ c:c.slug })}">${U.esc(c.nombre)}</a>`).join('');
    return `
<footer class="footer">
  <div class="container">
    <div class="footer__grid">
      <div>
        <a class="logo" href="index.html"><span class="logo__mark" aria-hidden="true">💃</span>
          <span class="logo__text">¿DÓNDE HAY <b>SALSA</b>?</span></a>
        <p class="text-soft" style="margin-top:.8rem;font-size:.875rem;max-width:38ch">
          ${U.esc(DHS.config.tagline)}. Encuentra sociales, clases, conciertos y festivales cerca de ti.
        </p>
      </div>
      <div>
        <h4>Ciudades</h4>
        ${ciudadesActivas}
        <a href="index.html#ciudades">Ver todas</a>
      </div>
      <div>
        <h4>Plataforma</h4>
        <a href="index.html#cartelera">Cartelera</a>
        <a href="publicar.html">Publicar evento</a>
        <a href="index.html#organizadores">Para organizadores</a>
      </div>
    </div>
    <div class="footer__bottom">
      <span>© ${new Date().getFullYear()} ${U.esc(DHS.config.nombre)} · Puerto Vallarta, México</span>
      <span>Datos de demostración · v1.0</span>
    </div>
  </div>
</footer>`;
  }

  function montar(activo){
    const head = document.getElementById('site-header');
    const foot = document.getElementById('site-footer');
    if (head) head.innerHTML = navbar(activo);
    if (foot) foot.innerHTML = footer();

    const burger = document.querySelector('.nav__burger');
    const menu   = document.getElementById('menu-movil');
    if (burger && menu){
      burger.addEventListener('click', () => {
        const abierto = burger.getAttribute('aria-expanded') === 'true';
        burger.setAttribute('aria-expanded', String(!abierto));
        burger.setAttribute('aria-label', abierto ? 'Abrir menú' : 'Cerrar menú');
        menu.classList.toggle('is-open', !abierto);
        document.body.classList.toggle('no-scroll', !abierto);
      });
      menu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
        burger.setAttribute('aria-expanded','false');
        menu.classList.remove('is-open');
        document.body.classList.remove('no-scroll');
      }));
    }
  }

  return { montar };
})();
