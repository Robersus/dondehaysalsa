/* ==========================================================================
   Filtros de cartelera. Se auto-construye desde los catálogos de datos,
   por eso agregar una ciudad o un ritmo nuevo no requiere tocar este archivo.
   ========================================================================== */
window.DHS = window.DHS || {};

DHS.filters = (function(){
  const U = DHS.util;

  function opciones(lista, valorTodos, etiquetaTodos){
    return [`<option value="${valorTodos}">${etiquetaTodos}</option>`]
      .concat(lista.map(x => `<option value="${x.slug}">${U.esc(x.nombre)}</option>`)).join('');
  }

  function render(contenedor, opts){
    const ciudades = DHS.ciudades.filter(c => c.activa);
    const bloqueCiudad = opts && opts.ciudadFija ? '' : `
      <div class="field">
        <label for="f-ciudad">📍 Ciudad</label>
        <select class="select" id="f-ciudad">${opciones(ciudades,'todas','Todas')}</select>
      </div>`;

    contenedor.innerHTML = `
<form class="filters" id="form-filtros" role="search">
  <div class="field">
    <label for="f-q">¿Qué estás buscando?</label>
    <input class="input" id="f-q" type="search" placeholder="Social, bachata, clase, nombre del lugar…" autocomplete="off">
  </div>
  <div class="filters__row" style="${opts && opts.ciudadFija ? 'grid-template-columns:repeat(3,1fr)' : ''}">
    ${bloqueCiudad}
    <div class="field">
      <label for="f-fecha">📅 Fecha</label>
      <select class="select" id="f-fecha">${DHS.rangosFecha.map(r => `<option value="${r.slug}">${r.nombre}</option>`).join('')}</select>
    </div>
    <div class="field">
      <label for="f-tipo">💃 Tipo de evento</label>
      <select class="select" id="f-tipo">${opciones(DHS.tiposEvento,'todos','Todos')}</select>
    </div>
    <div class="field">
      <label for="f-ritmo">🎵 Ritmo</label>
      <select class="select" id="f-ritmo">${opciones(DHS.ritmos,'todos','Todos')}</select>
    </div>
  </div>
  <div style="display:flex;gap:.75rem;flex-wrap:wrap">
    <button class="btn btn--primary" type="submit">BUSCAR EVENTOS</button>
    <button class="btn btn--ghost" type="button" id="btn-limpiar">Limpiar filtros</button>
  </div>
</form>`;
  }

  function leer(estadoBase){
    const v = id => { const el = document.getElementById(id); return el ? el.value : ''; };
    return {
      q:      v('f-q'),
      ciudad: (estadoBase && estadoBase.ciudadFija) || v('f-ciudad') || 'todas',
      fecha:  v('f-fecha') || 'todos',
      tipo:   v('f-tipo')  || 'todos',
      ritmo:  v('f-ritmo') || 'todos'
    };
  }

  function escribir(estado){
    const set = (id,val) => { const el = document.getElementById(id); if (el && val) el.value = val; };
    set('f-q', estado.q); set('f-ciudad', estado.ciudad); set('f-fecha', estado.fecha);
    set('f-tipo', estado.tipo); set('f-ritmo', estado.ritmo);
  }

  /** Chips rápidos de fecha, sincronizados con el select. */
  function quickchips(contenedor, onChange){
    contenedor.innerHTML = DHS.rangosFecha.map((r,i) =>
      `<button class="pill${i === 0 ? ' is-active' : ''}" type="button" data-fecha="${r.slug}">${r.nombre}</button>`).join('');
    contenedor.addEventListener('click', e => {
      const b = e.target.closest('.pill'); if (!b) return;
      contenedor.querySelectorAll('.pill').forEach(p => p.classList.remove('is-active'));
      b.classList.add('is-active');
      const sel = document.getElementById('f-fecha'); if (sel) sel.value = b.dataset.fecha;
      onChange();
    });
  }

  function sincronizarChips(valor){
    document.querySelectorAll('.quickfilters .pill').forEach(p =>
      p.classList.toggle('is-active', p.dataset.fecha === (valor || 'todos')));
  }

  return { render, leer, escribir, quickchips, sincronizarChips };
})();
