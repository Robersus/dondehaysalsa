/* ==========================================================================
   Tarjeta de evento. Un solo componente para home, ciudad y resultados.
   ========================================================================== */
window.DHS = window.DHS || {};

DHS.eventCard = (function(){
  const U = DHS.util;

  function html(ev){
    const f = U.fechaCorta(ev.fecha);
    const rel = U.fechaRelativa(ev.fecha);
    const destacado = ev.destacado ? '<span class="chip chip--gold">⭐ Destacado</span>' : '';
    const urgente = (rel === 'Hoy' || rel === 'Mañana') ? `<span class="chip chip--accent">${rel}</span>` : '';
    const href = U.url('evento.html', { id: ev.id });

    return `
<article class="card reveal${ev.destacado ? ' card--featured' : ''}">
  <a class="card__media" href="${href}" aria-label="Ver ${U.esc(ev.nombre)}">
    <img src="${U.esc(ev.flyer)}" alt="Flyer de ${U.esc(ev.nombre)}" loading="lazy" width="800" height="1000">
    <span class="card__flags">${destacado}${urgente}</span>
    <span class="card__date"><b>${f.dia}</b><span>${f.mes}</span></span>
  </a>
  <div class="card__body">
    <div class="card__flags" style="position:static">
      <span class="chip">${ev.tipoObj.icono} ${U.esc(ev.tipoObj.nombre)}</span>
    </div>
    <h3 class="card__title"><a href="${href}">${U.esc(ev.nombre)}</a></h3>
    <div class="card__meta">
      <span>🗓️ ${U.esc(U.fechaLarga(ev.fecha))} · ${U.hora12(ev.hora)}</span>
      <span>📍 ${U.esc(ev.lugar)}, ${U.esc(ev.ciudadNombre)}</span>
      <span>🎵 ${U.esc(ev.ritmosNombres.join(' + '))}</span>
    </div>
    <div class="card__foot">
      <span class="card__price">${U.esc(U.precio(ev.precio))}<small>${ev.precio ? 'por persona' : 'entrada libre'}</small></span>
      <a class="card__link" href="${href}">Ver evento</a>
    </div>
  </div>
</article>`;
  }

  /** Pinta una lista completa dentro de un contenedor, con estado vacío incluido. */
  function pintar(contenedor, eventos, mensajeVacio){
    if (!contenedor) return;
    if (!eventos.length){
      contenedor.className = '';
      contenedor.innerHTML = `
        <div class="empty">
          <h3>No encontramos eventos con esos filtros</h3>
          <p>${mensajeVacio || 'Prueba con otra fecha o quita algún filtro. La cartelera crece cada semana.'}</p>
          <p style="margin-top:1rem"><a class="btn btn--ghost" href="publicar.html">¿Organizas uno? Publícalo</a></p>
        </div>`;
      return;
    }
    contenedor.className = 'grid-events';
    contenedor.innerHTML = eventos.map(html).join('');
    U.observarReveal(contenedor);
  }

  return { html, pintar };
})();
